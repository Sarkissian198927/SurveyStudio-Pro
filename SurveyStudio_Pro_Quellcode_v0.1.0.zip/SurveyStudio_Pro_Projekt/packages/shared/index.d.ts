export type QuestionType = 'short_text' | 'long_text' | 'number' | 'date' | 'email' | 'boolean' | 'single_choice' | 'multi_choice' | 'dropdown';
export type QuestionOption = { value: string; label: string };
export type SurveyQuestion = {
  key: string;
  type: QuestionType;
  label: string;
  description: string;
  required: boolean;
  options: QuestionOption[];
  style?: { bold?: boolean; italic?: boolean; color?: string };
  validation?: { min?: number; max?: number; minLength?: number; maxLength?: number };
};
export type SurveyDraft = {
  schemaVersion: '1.0';
  metadata: { title: string; description: string; intro: string; outro: string };
  theme: { primaryColor: string; backgroundColor: string; textColor: string; fontFamily: string; backgroundImage: string | null; logoImage: string | null };
  pages: { key: string; title: string; questionKeys: string[] }[];
  questions: SurveyQuestion[];
  settings: { showProgress: boolean };
  privacy: { mode: 'anonymous'; privacyNotice: string };
};
export type ValidationResult = { ok: boolean; errors: string[] };
export const QUESTION_TYPES: { id: QuestionType; label: string; icon: string }[];
export function newQuestion(type: QuestionType): SurveyQuestion;
export function createDraft(title?: string): SurveyDraft;
export function addQuestion(draft: SurveyDraft, type: QuestionType): SurveyDraft;
export function duplicateQuestion(draft: SurveyDraft, key: string): SurveyDraft;
export function removeQuestion(draft: SurveyDraft, key: string): SurveyDraft;
export function moveQuestion(draft: SurveyDraft, key: string, offset: number): SurveyDraft;
export function validateDraft(draft: unknown, forPublish?: boolean): ValidationResult;
export function validateAnswers(draft: SurveyDraft, answers: Record<string, unknown>): ValidationResult;
export function calculateResults(draft: SurveyDraft, rows: { question_key: string; answer_json: unknown }[], totalResponses: number): {
  totalResponses: number;
  questions: { key: string; type: QuestionType; label: string; counts?: { label: string; count: number; percentage: number }[]; answered: number; mean?: number | null }[];
};
