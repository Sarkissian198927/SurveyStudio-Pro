import { Module } from '@nestjs/common';
import { APP_GUARD } from '@nestjs/core';
import { JwtModule } from '@nestjs/jwt';
import { AuthController, AuthService, SessionGuard } from './auth';
import { Database } from './database';
import { ProjectController, ProjectService } from './projects';
import { SurveyController, SurveyService } from './surveys';
import { PublicController, PublicSurveyService } from './public';
@Module({
 imports:[JwtModule.register({secret:process.env.JWT_SECRET})],
 controllers:[AuthController,ProjectController,SurveyController,PublicController],
 providers:[Database,AuthService,ProjectService,SurveyService,PublicSurveyService,{provide:APP_GUARD,useClass:SessionGuard}]
})
export class AppModule {}
