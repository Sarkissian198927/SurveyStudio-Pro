import { BadRequestException, Body, CanActivate, ConflictException, Controller, createParamDecorator, ExecutionContext, ForbiddenException, Get, Injectable, Post, Res, SetMetadata, UnauthorizedException, UseGuards } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcryptjs';
import { randomBytes } from 'node:crypto';
import { Request, Response } from 'express';
import { Database } from './database';

export const PUBLIC = 'survey_public_endpoint';
export const Public = () => SetMetadata(PUBLIC,true);
export type Viewer = { id: string; csrf: string };
export const CurrentUser = createParamDecorator((_data: unknown, ctx: ExecutionContext) => ctx.switchToHttp().getRequest<Request & {viewer:Viewer}>().viewer);
@Injectable()
export class SessionGuard implements CanActivate {
  constructor(private readonly jwt: JwtService, private readonly db: Database, private readonly reflector: Reflector) {}
  async canActivate(context: ExecutionContext): Promise<boolean> {
    if(this.reflector.getAllAndOverride<boolean>(PUBLIC,[context.getHandler(),context.getClass()])) return true;
    const req = context.switchToHttp().getRequest<Request & {viewer:Viewer}>();
    const token = req.cookies?.survey_session;
    if(typeof token !== 'string') throw new UnauthorizedException('Bitte anmelden.');
    let session: {sub: string; csrf: string};
    try { session = await this.jwt.verifyAsync<{sub:string;csrf:string}>(token); }
    catch { throw new UnauthorizedException('Anmeldung abgelaufen.'); }
    const user = await this.db.query('SELECT id FROM users WHERE id=$1 AND status=$2',[session.sub,'active']);
    if(!user.rowCount) throw new UnauthorizedException('Konto nicht verfügbar.');
    if(['POST','PUT','PATCH','DELETE'].includes(req.method) && req.headers['x-survey-csrf'] !== session.csrf)
      throw new ForbiddenException('CSRF-Schutz: Sitzung erneut laden.');
    req.viewer = {id:session.sub, csrf:session.csrf};
    return true;
  }
}
@Injectable()
export class AuthService {
  constructor(private readonly db:Database, private readonly jwt: JwtService) {}
  private async createSession(userId:string, response:Response) {
    const csrf=randomBytes(24).toString('hex');
    const token=await this.jwt.signAsync({sub:userId,csrf},{expiresIn:'8h'});
    response.cookie('survey_session',token,{
      httpOnly:true,sameSite:'lax',secure:process.env.COOKIE_SECURE==='true',
      maxAge:8*60*60*1000,path:'/api/v1'
    });
    return csrf;
  }
  async register(data:any,response:Response) {
    const email=typeof data?.email==='string'?data.email.trim().toLowerCase():'';
    const displayName=typeof data?.displayName==='string'?data.displayName.trim():'';
    const password=data?.password;
    if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length>320 || !displayName || displayName.length>120 || typeof password!=='string' || password.length<12 || password.length>200)
      throw new BadRequestException('Bitte gültige E-Mail, Namen und ein Passwort mit mindestens 12 Zeichen eingeben.');
    const hashed=await bcrypt.hash(password,12);
    let userId:string;
    try {
      userId=await this.db.transaction(async client=>{
        const u=await client.query('INSERT INTO users(email,display_name,password_hash) VALUES($1,$2,$3) RETURNING id',[email,displayName,hashed]);
        const org=await client.query('INSERT INTO organizations(name) VALUES($1) RETURNING id',[`${displayName} – Arbeitsbereich`]);
        const project=await client.query('INSERT INTO projects(organization_id,title) VALUES($1,$2) RETURNING id',[org.rows[0].id,'Mein erstes Projekt']);
        await client.query('INSERT INTO organization_members VALUES($1,$2,$3)',[org.rows[0].id,u.rows[0].id,'owner']);
        await client.query('INSERT INTO project_members VALUES($1,$2,$3)',[project.rows[0].id,u.rows[0].id,'owner']);
        return u.rows[0].id as string;
      });
    } catch(error:any) { if(error?.code==='23505') throw new ConflictException('Diese E-Mail-Adresse ist bereits registriert.'); throw error; }
    return {user:{id:userId,email,displayName},csrfToken:await this.createSession(userId,response)};
  }
  async login(data:any,response:Response) {
    const email=typeof data?.email==='string'?data.email.trim().toLowerCase():'';
    const user=await this.db.query('SELECT id,email,display_name,password_hash FROM users WHERE lower(email)=$1 AND status=$2',[email,'active']);
    const valid=user.rowCount && typeof data?.password==='string' && await bcrypt.compare(data.password,user.rows[0].password_hash);
    if(!valid) throw new UnauthorizedException('E-Mail oder Passwort ist falsch.');
    const u=user.rows[0];
    return {user:{id:u.id,email:u.email,displayName:u.display_name},csrfToken:await this.createSession(u.id,response)};
  }
  async me(viewer:Viewer) {
    const {rows}=await this.db.query('SELECT id,email,display_name FROM users WHERE id=$1',[viewer.id]);
    return {user:{id:rows[0].id,email:rows[0].email,displayName:rows[0].display_name},csrfToken:viewer.csrf};
  }
}
@Controller('auth')
export class AuthController {
  constructor(private readonly auth:AuthService) {}
  @Public() @Post('register') register(@Body() body:any,@Res({passthrough:true}) res:Response) {return this.auth.register(body,res);}
  @Public() @Post('login') login(@Body() body:any,@Res({passthrough:true}) res:Response) {return this.auth.login(body,res);}
  @Get('me') me(@CurrentUser() viewer:Viewer) {return this.auth.me(viewer);}
  @Post('logout') logout(@Res({passthrough:true}) res:Response) {res.clearCookie('survey_session',{path:'/api/v1'});return {ok:true};}
}
