import { BadRequestException, Body, ConflictException, Controller, Get, HttpCode, Injectable, NotFoundException, Param, Post } from '@nestjs/common';
import { SurveyDraft, validateAnswers } from '@surveystudio/shared';
import { createHash } from 'node:crypto';
import { Database } from './database';
import { Public } from './auth';
@Injectable()
export class PublicSurveyService {
 constructor(private readonly db:Database) {}
 async publication(slug:string) {
   if(!/^[\w-]{16,80}$/.test(slug)) throw new NotFoundException('Umfrage nicht gefunden.');
   const result=await this.db.query(`SELECT p.id,p.organization_id,p.survey_version_id,p.state,p.opens_at,p.closes_at,p.max_responses,v.document
      FROM publications p JOIN survey_versions v ON v.id=p.survey_version_id WHERE p.slug=$1`,[slug]);
   if(!result.rowCount) throw new NotFoundException('Umfrage nicht gefunden.');
   const publication=result.rows[0];
   const now=Date.now();
   if(publication.state!=='active' || (publication.opens_at && +new Date(publication.opens_at)>now) || (publication.closes_at && +new Date(publication.closes_at)<now))
     throw new NotFoundException('Diese Umfrage nimmt derzeit keine Antworten entgegen.');
   return publication;
 }
 async get(slug:string) {
   const p=await this.publication(slug);
   return {document:p.document};
 }
 async submit(slug:string,body:any) {
   const p=await this.publication(slug);
   if(!body || typeof body!=='object' || !/^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/.test(body.idempotencyKey)) throw new BadRequestException('Eine gültige eindeutige Abgabe-ID fehlt.');
   const checked=validateAnswers(p.document as SurveyDraft,body.answers);
   if(!checked.ok) throw new BadRequestException({message:'Bitte Eingaben korrigieren.',errors:checked.errors});
   const answers=body.answers as Record<string,unknown>;
   const sha=createHash('sha256').update(JSON.stringify(answers)).digest('hex');
   return this.db.transaction(async client=>{
     // A row lock serializes response-cap checks, preventing overbooking.
     const locked=await client.query('SELECT id,max_responses FROM publications WHERE id=$1 AND state=$2 FOR UPDATE',[p.id,'active']);
     if(!locked.rowCount) throw new ConflictException('Umfrage inzwischen geschlossen.');
     const existing=await client.query('SELECT id,answer_sha256 FROM response_sessions WHERE publication_id=$1 AND idempotency_key=$2',[p.id,body.idempotencyKey]);
     if(existing.rowCount) {
       if(existing.rows[0].answer_sha256!==sha) throw new ConflictException('Diese Abgabe-ID gehört bereits zu einer anderen Antwort.');
       return {ok:true,submissionId:existing.rows[0].id,duplicate:true};
     }
     if(locked.rows[0].max_responses) {
       const count=await client.query('SELECT count(*)::integer AS total FROM response_sessions WHERE publication_id=$1',[p.id]);
       if(count.rows[0].total>=locked.rows[0].max_responses) throw new ConflictException('Die maximale Anzahl an Antworten ist erreicht.');
     }
     const saved=await client.query(`INSERT INTO response_sessions(organization_id,publication_id,survey_version_id,idempotency_key,answer_sha256)
       VALUES($1,$2,$3,$4,$5) RETURNING id`,[p.organization_id,p.id,p.survey_version_id,body.idempotencyKey,sha]);
     for(const [questionKey,value] of Object.entries(answers)) {
       if(value===null || value===undefined || value==='' || (Array.isArray(value)&&value.length===0)) continue;
       await client.query('INSERT INTO response_items(session_id,question_key,answer_json) VALUES($1,$2,$3::jsonb)',[saved.rows[0].id,questionKey,JSON.stringify(value)]);
     }
     return {ok:true,submissionId:saved.rows[0].id,duplicate:false};
   });
 }
}
@Public()
@Controller('public/s')
export class PublicController {
 constructor(private readonly service:PublicSurveyService) {}
 @Get(':slug') get(@Param('slug') slug:string) {return this.service.get(slug);}
 @Post(':slug/responses') @HttpCode(201) submit(@Param('slug') slug:string,@Body() body:any) {return this.service.submit(slug,body);}
}
