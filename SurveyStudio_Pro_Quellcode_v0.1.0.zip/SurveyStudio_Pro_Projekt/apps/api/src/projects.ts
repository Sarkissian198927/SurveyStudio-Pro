import { BadRequestException, Body, Controller, ForbiddenException, Get, Injectable, Post } from '@nestjs/common';
import { CurrentUser, Viewer } from './auth';
import { Database } from './database';
@Injectable()
export class ProjectService {
 constructor(private readonly db:Database) {}
 async list(userId:string) {
   const result=await this.db.query('SELECT p.id,p.organization_id,p.title,pm.role,p.created_at FROM projects p JOIN project_members pm ON pm.project_id=p.id WHERE pm.user_id=$1 ORDER BY p.created_at',[userId]);
   return result.rows;
 }
 async role(projectId:string,userId:string,needWrite=false) {
   const result=await this.db.query('SELECT role FROM project_members WHERE project_id=$1 AND user_id=$2',[projectId,userId]);
   if(!result.rowCount) throw new ForbiddenException('Kein Zugriff auf das Projekt.');
   if(needWrite && result.rows[0].role==='viewer') throw new ForbiddenException('Keine Bearbeitungsrechte.');
   return result.rows[0].role as string;
 }
 async create(userId:string,title:string) {
   if(!title?.trim() || title.length>160) throw new BadRequestException('Projektname ungültig.');
   const org=await this.db.query('SELECT organization_id FROM organization_members WHERE user_id=$1 AND role IN ($2,$3) LIMIT 1',[userId,'owner','admin']);
   if(!org.rowCount) throw new ForbiddenException('Keine Berechtigung zur Projekterstellung.');
   return this.db.transaction(async client=>{
     const result=await client.query('INSERT INTO projects(organization_id,title) VALUES($1,$2) RETURNING id,organization_id,title,created_at',[org.rows[0].organization_id,title.trim()]);
     await client.query('INSERT INTO project_members VALUES ($1,$2,$3)',[result.rows[0].id,userId,'owner']);
     return result.rows[0];
   });
 }
}
@Controller('projects')
export class ProjectController {
 constructor(private readonly projects:ProjectService) {}
 @Get() list(@CurrentUser() viewer:Viewer) {return this.projects.list(viewer.id);}
 @Post() create(@CurrentUser() viewer:Viewer,@Body() data:{title:string}) {return this.projects.create(viewer.id,data?.title);}
}
