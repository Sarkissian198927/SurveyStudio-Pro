import 'reflect-metadata';
import { config } from 'dotenv';
import { resolve } from 'node:path';
config({path:resolve(__dirname,'../../../.env')});
import { NestFactory } from '@nestjs/core';
import cookieParser from 'cookie-parser';
import { json } from 'express';
async function bootstrap() {
  if(!process.env.DATABASE_URL) throw new Error('DATABASE_URL fehlt in .env');
  if(!process.env.JWT_SECRET || process.env.JWT_SECRET.length<32) throw new Error('JWT_SECRET muss mindestens 32 Zeichen enthalten');
  if(process.env.NODE_ENV==='production' && process.env.COOKIE_SECURE!=='true') throw new Error('In Produktion ist COOKIE_SECURE=true erforderlich.');
  const {AppModule}=await import('./app.module');
  const app=await NestFactory.create(AppModule,{bodyParser:false});
  app.setGlobalPrefix('api/v1');
  app.enableCors({origin:process.env.WEB_ORIGIN||'http://localhost:5173',credentials:true,allowedHeaders:['Content-Type','X-Survey-CSRF'],methods:['GET','POST','PATCH','OPTIONS']});
  app.use(cookieParser());
  // Do not record participant IPs or user agents in application logs.
  app.use(json({limit:'4mb'}));
  await app.listen(Number(process.env.API_PORT)||3001,'127.0.0.1');
  console.log(`SurveyStudio API unter http://localhost:${process.env.API_PORT||3001}/api/v1`);
}
bootstrap().catch(e=>{console.error(e);process.exit(1);});
