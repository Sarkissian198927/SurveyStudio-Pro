import { useState, type FormEvent, type CSSProperties } from 'react';
import type { SurveyDraft, SurveyQuestion } from '@surveystudio/shared';
import { validateAnswers } from '@surveystudio/shared';
import { ArrowLeft, ArrowRight, CheckCircle2, Send } from 'lucide-react';

type Props={draft:SurveyDraft; preview?:boolean; onSubmit?:(answers:Record<string,unknown>)=>Promise<void>};
export function SurveyForm({draft,preview=false,onSubmit}:Props) {
 const [answers,setAnswers]=useState<Record<string,unknown>>({});
 const [error,setError]=useState('');
 const [sending,setSending]=useState(false);
 const [complete,setComplete]=useState(false);
 const [started,setStarted]=useState(false);
 const set=(key:string,value:unknown)=>setAnswers(old=>({...old,[key]:value}));
 const sorted=draft.pages[0].questionKeys.map(key=>draft.questions.find(q=>q.key===key)).filter((q):q is SurveyQuestion=>!!q);
 const themeStyle={
   '--survey-accent':draft.theme.primaryColor,
   backgroundColor:draft.theme.backgroundColor,
   color:draft.theme.textColor,
   fontFamily:draft.theme.fontFamily,
   ...(draft.theme.backgroundImage?{backgroundImage:`linear-gradient(rgba(248,250,254,.87),rgba(248,250,254,.9)),url(${draft.theme.backgroundImage})`,backgroundSize:'cover',backgroundPosition:'center'}:{})
 } as CSSProperties;
 async function submit(e:FormEvent) {
   e.preventDefault();
   const result=validateAnswers(draft,answers);
   if(!result.ok) {setError(result.errors[0]);return;}
   setError('');setSending(true);
   try {if(!preview) await onSubmit?.(answers);setComplete(true);}catch(e) {setError(e instanceof Error?e.message:'Die Übermittlung ist fehlgeschlagen.');}finally{setSending(false);}
 }
 return <div className="survey-runtime" style={themeStyle}>
   <div className="survey-paper">
    {preview && <div className="preview-ribbon">VORSCHAU · Antworten werden nicht gespeichert</div>}
    {draft.theme.logoImage && <img className="survey-logo" src={draft.theme.logoImage} alt="Umfragelogo"/>}
    {complete ? <div className="runtime-message"><CheckCircle2 size={44} color={draft.theme.primaryColor}/><h1>Geschafft!</h1><p>{draft.metadata.outro}</p>{preview&&<button className="outline-btn" onClick={()=>{setComplete(false);setAnswers({});setStarted(false);}}>Vorschau neu starten</button>}</div>
    : !started ? <div className="runtime-message intro-message"><span className="eyebrow">WILLKOMMEN</span><h1>{draft.metadata.title}</h1><p>{draft.metadata.intro}</p>{draft.metadata.description&&<p className="muted">{draft.metadata.description}</p>}<button className="primary-btn" type="button" onClick={()=>setStarted(true)}>Umfrage starten <ArrowRight size={17}/></button><p className="notice">{draft.privacy.privacyNotice}</p></div>
    : <form onSubmit={submit} noValidate>
       <div className="survey-form-heading"><span className="eyebrow">IHRE MEINUNG ZÄHLT</span><h1>{draft.metadata.title}</h1><p>{draft.metadata.description}</p></div>
       {sorted.map((q,i)=><div className="runtime-question" key={q.key}><label className="runtime-question-label" style={{fontWeight:q.style?.bold?800:600,fontStyle:q.style?.italic?'italic':'normal',color:q.style?.color||draft.theme.textColor}}>{i+1}. {q.label} {q.required&&<span className="required">*</span>}</label>{q.description&&<p className="question-help">{q.description}</p>}<AnswerInput q={q} value={answers[q.key]} onChange={value=>set(q.key,value)}/></div>)}
       {!!error&&<p className="form-error" role="alert">{error}</p>}
       <div className="form-actions"><button type="button" className="link-btn" onClick={()=>setStarted(false)}><ArrowLeft size={16}/> Zurück</button><button type="submit" className="primary-btn" disabled={sending}>{sending?'Wird übertragen ...':preview?'Vorschau abschließen':'Antworten senden'} <Send size={16}/></button></div>
       <p className="notice">{draft.privacy.privacyNotice}</p>
    </form>}
   </div>
 </div>;
}
function AnswerInput({q,value,onChange}:{q:SurveyQuestion;value:unknown;onChange:(v:unknown)=>void}) {
 const common={className:'runtime-input','aria-label':q.label};
 switch(q.type) {
  case 'short_text': case 'email': return <input {...common} type={q.type==='email'?'email':'text'} value={typeof value==='string'?value:''} onChange={e=>onChange(e.target.value)} placeholder={q.type==='email'?'name@beispiel.de':'Ihre Antwort'}/>;
  case 'long_text':return <textarea {...common} rows={4} value={typeof value==='string'?value:''} onChange={e=>onChange(e.target.value)} placeholder="Ihre Antwort"/>;
  case 'number':return <input {...common} type="number" value={typeof value==='number'?value:''} onChange={e=>onChange(e.target.value===''?'':Number(e.target.value))}/>;
  case 'date':return <input {...common} type="date" value={typeof value==='string'?value:''} onChange={e=>onChange(e.target.value)}/>;
  case 'boolean':return <div className="choice-list">{[{value:true,label:'Ja'},{value:false,label:'Nein'}].map(o=><label className="choice-option" key={String(o.value)}><input type="radio" name={q.key} checked={value===o.value} onChange={()=>onChange(o.value)}/><span>{o.label}</span></label>)}</div>;
  case 'single_choice':return <div className="choice-list">{q.options.map(o=><label className="choice-option" key={o.value}><input type="radio" name={q.key} checked={value===o.value} onChange={()=>onChange(o.value)}/><span>{o.label}</span></label>)}</div>;
  case 'multi_choice':return <div className="choice-list">{q.options.map(o=><label className="choice-option" key={o.value}><input type="checkbox" checked={Array.isArray(value)&&value.includes(o.value)} onChange={e=>{const arr=Array.isArray(value)?value as string[]:[];onChange(e.target.checked?[...arr,o.value]:arr.filter(v=>v!==o.value));}}/><span>{o.label}</span></label>)}</div>;
  case 'dropdown':return <select {...common} value={typeof value==='string'?value:''} onChange={e=>onChange(e.target.value)}><option value="">Bitte auswählen ...</option>{q.options.map(o=><option value={o.value} key={o.value}>{o.label}</option>)}</select>;
 }
}
