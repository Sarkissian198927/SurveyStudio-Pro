import { useEffect, useRef, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, ArrowRight, BarChart3, CheckCircle2, ClipboardList, Loader2, ShieldCheck, TrendingUp } from 'lucide-react';
import type { SurveyDraft } from '@surveystudio/shared';
import { api } from './api';
import { AppShell } from './App';
import { SurveyForm } from './SurveyForm';

type Results={totalResponses:number;scope:string;suppressed?:boolean;questions:{key:string;type:string;label:string;answered:number;mean?:number|null;counts?:{label:string;count:number;percentage:number}[]}[]};
export function ResultsPage(){
 const {id}=useParams(),navigate=useNavigate();const [results,setResults]=useState<Results|null>(null),[error,setError]=useState('');
 useEffect(()=>{if(id)api<Results>(`/surveys/${id}/results`).then(setResults).catch(e=>setError(e.message));},[id]);
 return <AppShell title="Auswertung" subtitle="Aktuelle Ergebnisse und übersichtliche Diagramme" actions={<button className="outline-btn" onClick={()=>navigate(`/app/surveys/${id}/edit`)}><ArrowLeft size={16}/> Zum Designer</button>}>
 {error&&<div className="form-error">{error}</div>}
 {!results?<div className="center-inner"><Loader2 size={22} className="spin"/> Ergebnisse werden geladen ...</div>:<><div className="result-banner"><div><div className="eyebrow">UMFRAGE-AUSWERTUNG</div><h2>Alle Antworten auf einen Blick</h2><p>Die Statistiken beziehen sich auf die neueste veröffentlichte Fragebogenversion.</p></div><span><TrendingUp size={27}/> {results.totalResponses} Antworten</span></div><div className="stats-grid"><div className="stat-card"><span className="stat-icon blue"><ClipboardList size={20}/></span><div><small>Abgeschlossene Antworten</small><strong>{results.totalResponses}</strong></div></div><div className="stat-card"><span className="stat-icon green"><BarChart3 size={20}/></span><div><small>Ausgewertete Fragen</small><strong>{results.questions.length}</strong></div></div><div className="stat-card"><span className="stat-icon orange"><ShieldCheck size={20}/></span><div><small>Datenerhebung</small><strong className="stat-word">Anonym</strong></div></div></div>{results.questions.length===0?<div className="empty-state"><BarChart3 size={35}/><h3>{results.suppressed?'Ergebnisse aus Datenschutzgründen zurückgehalten':'Noch keine veröffentlichten Fragen'}</h3><p>{results.suppressed?'Für Nutzer mit Leserechten werden Auswertungen mit weniger als fünf Antworten nicht angezeigt.':'Veröffentliche deinen Fragebogen und sammle Antworten.'}</p></div>:<div className="results-grid">{results.questions.map((q,i)=><div className="result-card" key={q.key}><span className="eyebrow">FRAGE {i+1} · {q.answered} ANTWORTEN</span><h3>{q.label}</h3>{q.counts?<div className="bar-list">{q.counts.map(c=><div key={c.label}><div className="bar-text"><span>{c.label}</span><strong>{c.percentage}% <small>({c.count})</small></strong></div><div className="bar-track"><div className="bar-fill" style={{width:`${c.percentage}%`}}/></div></div>)}</div>:q.type==='number'?<div className="average-result"><span>Durchschnittswert</span><strong>{q.mean??'–'}</strong></div>:<p className="hint">{q.answered} Texteingaben. Freitextantworten werden in dieser ersten Version nicht als Rohdaten angezeigt.</p>}</div>)}</div>}<div className="warning-note">Für eine produktive Veröffentlichung fehlen noch eine Freigabeprüfung, Unterdrückung kleiner Ergebnisgruppen und erweiterte Datenschutzfunktionen. Keine sensiblen Produktivdaten verwenden.</div></>}
 </AppShell>;
}
export function PublicSurveyPage(){
 const {slug}=useParams();const [draft,setDraft]=useState<SurveyDraft|null>(null),[error,setError]=useState('');
 const submissionKey=useRef(crypto.randomUUID());
 useEffect(()=>{if(!slug)return;api<{document:SurveyDraft}>(`/public/s/${encodeURIComponent(slug)}`).then(r=>setDraft(r.document)).catch(e=>setError(e.message));},[slug]);
 async function submit(answers:Record<string,unknown>){await api(`/public/s/${encodeURIComponent(slug!)}/responses`,{method:'POST',body:JSON.stringify({idempotencyKey:submissionKey.current,answers})});}
 if(error)return <div className="public-error"><div><ClipboardList size={29}/><h2>Diese Umfrage ist nicht verfügbar.</h2><p>{error}</p><Link to="/app">Zu SurveyStudio <ArrowRight size={16}/></Link></div></div>;
 if(!draft)return <div className="center-screen"><Loader2 className="spin"/> Umfrage wird geladen ...</div>;
 return <div className="public-wrapper"><header className="public-header"><span className="public-brand"><ClipboardList size={19}/> SurveyStudio Pro</span><span><ShieldCheck size={15}/> Sichere Fragebogenübertragung</span></header><SurveyForm draft={draft} onSubmit={submit}/><footer className="public-footer"><CheckCircle2 size={14}/> Erstellt mit SurveyStudio Pro</footer></div>;
}
