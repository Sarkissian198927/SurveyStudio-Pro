export class ApiError extends Error {
 constructor(message: string, public status: number, public details: string[] = []) {super(message);}
}
let csrf = '';
export const setCsrf = (token: string) => {csrf=token;};
export async function api<T>(path: string, options: RequestInit = {}): Promise<T> {
 const method=(options.method||'GET').toUpperCase();
 const response=await fetch(`/api/v1${path}`,{
   ...options, credentials:'include',
   headers:{'Content-Type':'application/json',...(csrf && !['GET','HEAD'].includes(method)?{'X-Survey-CSRF':csrf}:{}),...options.headers}
 });
 if(!response.ok) {
   const body=await response.json().catch(()=>({message:'Ein unerwarteter Fehler ist aufgetreten.'}));
   const errors=Array.isArray(body?.errors)?body.errors:Array.isArray(body?.message)?body.message:[];
   throw new ApiError(Array.isArray(body?.message)?body.message.join(' | '):(body?.message||'Verbindung fehlgeschlagen.'),response.status,errors);
 }
 return response.json() as Promise<T>;
}
export type AppUser = {id:string;email:string;displayName:string};
export type Session = {user:AppUser;csrfToken:string};
export type Project = {id:string;organization_id:string;title:string;role:string};
export type SurveyItem = {id:string;title:string;state:string;updated_at:string;revision:number;response_count:number};
export type Publication = {slug:string;state:string;created_at:string};
