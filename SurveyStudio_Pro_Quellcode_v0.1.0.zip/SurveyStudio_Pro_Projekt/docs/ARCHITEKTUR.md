# SurveyStudio Pro – Architekturentscheidungen (Implementierungsstand 0.1)

## Zielbild

Dieses Teilprojekt deckt **die technische Basis und einen ersten benutzbaren Web-Fragebogen-Designer** ab. Für den Endausbau gilt das Pflichtenheft v1.0; der jetzige Stand ist nicht mit Produktversion 1.0 gleichzusetzen.

### Komponenten und Verantwortlichkeiten

```text
Browser (React/Vite, :5173)
  ├─ Admin-Sitzung → /api/v1/auth, /projects, /surveys
  └─ öffentlicher Aufruf → /api/v1/public/s/:slug
           │ (Vite-Proxy in Entwicklung)
NestJS API (:3001)
  ├─ SessionGuard: HttpOnly JWT Cookie + headergebundener CSRF-Schutz
  ├─ AuthService: Registrierung, Login, Benutzeridentität
  ├─ ProjectService: Rollenkontrolle auf Projektebene
  ├─ SurveyService: Entwürfe, Revisionen, Veröffentlichung, Aggregate
  └─ PublicSurveyService: Antwortvalidierung, idempotente Speicherung
           │
PostgreSQL 16
  ├─ Benutzer, Arbeitsbereiche, Projekte und Mitgliedschaften
  ├─ Umfragen, änderbare Entwürfe, unveränderliche Versionen
  └─ Veröffentlichungen, Antwortsitzungen, Antwortwerte
```

### Entscheidungen (ADR-Kurzfassung)

- **ADR-001: Monorepo mit npm Workspaces.** Das Paket `packages/shared` ist CommonJS mit TypeScript-Deklarationen, da sich NestJS/Node und Vite den Fachcode teilen können. Ziel für spätere Versionen ist eine duale ESM/CJS-Publikation des Shared-Pakets.
- **ADR-002: JSONB-Dokumente für Entwürfe.** Beibehaltung stabiler Frage-IDs, SchemaVersion, Seitenreferenzen und Präsentationsthemen; damit können Fragearten erweitert werden. Antworten bleiben zusätzlich relational gespeichert.
- **ADR-003: Optimistische Revisionsprüfung.** `UPDATE survey_drafts ... WHERE revision=$expected`; bei Konflikt HTTP 409 statt Überschreiben. UI bietet dann Neuladen an. Diese Lösung verhindert stille Verluste, ist noch keine konfliktfreie Echtzeitkooperation.
- **ADR-004: Veröffentlichungen als Snapshots.** Der Server erstellt eine unveränderliche `survey_versions`-Zeile mit SHA256 über das Schema; neue Publikationen schließen frühere Publikationen dieser Umfrage. Erfasste Antworten bleiben referenziert auf der Version, zu der sie eingereicht wurden.
- **ADR-005: Separate öffentliche API.** Im Adminbereich sind Cookies/Projektberechtigungen erforderlich; öffentliche Formulare benötigen keine Benutzerkonten. Aktuell unterstützt die öffentliche API ausschließlich anonym bezeichnete Umfragen. Anonymität ist ohne weitere Prüfungen nicht garantiert.
- **ADR-006: Idempotente Einreichung.** Der Client übermittelt eine stabile UUID. Das DB-Unique-Constraint `(publication_id,idempotency_key)` und der Vergleich des Antwort-Hashes verhindern Duplikate und unbemerkte Änderungen bei Wiederholungen.
- **ADR-007: Kein externer Font- oder Analytics-CDN.** Der Frontend-Code bindet keine externen Tracking- oder Font-URLs ein. Layoutschriftarten nutzen lokale Browser-Fallbacks. Dieser Stand ist ein Beitrag zur Datenminimierung, ersetzt aber keine Datenschutzfreigabe.
- **ADR-008: Assets vorläufig eingebettet.** Nur PNG/JPG/WebP bis 1,4 MB, serverseitiger Data-URL-Check. Vor Produktivbetrieb sollen Logos/Hintergrundbilder als geprüfte Assets im Objekt-Storage gespeichert werden.
- **ADR-009: Ergebnisdashboard der neuesten Veröffentlichung.** Werte aus älteren Fragebogenversionen werden nicht vermischt. Eine verlässliche versionsübergreifende Vergleichsansicht ist spätere Arbeit.

## Authentifizierungsmodell (nur Entwicklungs-/Pilotbetrieb)

Registrierung: E-Mail + Name + Passwort mit mindestens 12 Zeichen. Password-Hash durch bcrypt (Kostenfaktor 12). Login erzeugt signiertes JWT für acht Stunden, gespeichert in HttpOnly-Cookie mit SameSite=Lax; in Produktion ist `COOKIE_SECURE=true` zwingend. Mutierende geschützte API-Aufrufe benötigen ein X-Survey-CSRF-Token, das aus der gebundenen Sitzung stammt. Zusätzlich müssen Projektrollen beim Zugriff auf jede Umfrage kontrolliert werden.

**Nicht implementiert:** E-Mail-Verifikation, Passwort-Reset, 2FA, revisionssichere Schlüsselrotation, Geräte-/Sessionübersicht, Login-Drosselung, zentrale Rollenverwaltung und feingranulare Rechte auf Identitätslisten. Deshalb keine öffentliche Freigabe mit personenbezogenen Produktivdaten.

## Zugriffsmatrix aktueller Stand

| Operation | Owner | Editor | Viewer | Anonym |
|---|---:|---:|---:|---:|
| Projekt/Umfrage sehen | Ja | Ja | Ja | Nein |
| Umfrage erstellen/speichern | Ja | Ja | Nein | Nein |
| Umfrage veröffentlichen | Ja | Ja | Nein | Nein |
| Aktuelle Aggregate sehen | Ja | Ja | Ja | Nein |
| Öffentlichen Fragebogen abrufen/absenden | Ja | Ja | Ja | Ja |
| Rohantworten exportieren | Nicht implementiert | Nicht implementiert | Nicht implementiert | Nicht implementiert |

Mitgliedschaften anderer Personen können derzeit nur auf Datenbankebene eingerichtet werden; eine Benutzer-/Einladungs-UI steht aus.

## Datenbank

`db/migrations/001_initial.sql` enthält die in der ersten Version erforderlichen Tabellen und Constraints. Mit `npm run db:migrate` werden Migrationen alphabetisch ausgeführt und jeweils per SHA256 gegen nachträgliche Änderungen abgesichert. Unvollständige Migrationen werden über Transaktions-Rollback verworfen.

Zu beachten: Rückwärtsmigrationen, Datenrettungsplan, Partitionierung großer Antwortmengen, Backups, Löschfristen und ein späterer SQLite-Adapter sind noch nicht umgesetzt.

## API-Katalog (momentaner Implementierungsstand)

| Methode | Endpoint | Zugriff | Ergebnis |
|---|---|---|---|
| POST | `/api/v1/auth/register` | öffentlich | neues Konto, Workspace, Projekt, Sitzung |
| POST | `/api/v1/auth/login` | öffentlich | neue Sitzung |
| GET | `/api/v1/auth/me` | Sitzung | Benutzer und CSRF-Token |
| POST | `/api/v1/auth/logout` | Sitzung + CSRF | Cookie löschen |
| GET | `/api/v1/projects` | Sitzung | eigene Projekte |
| POST | `/api/v1/projects` | Sitzung + CSRF | neues Projekt |
| GET | `/api/v1/surveys?projectId=UUID` | Projektrolle | Umfrageliste |
| POST | `/api/v1/surveys` | Projekt-Editor + CSRF | neue Umfrage |
| GET | `/api/v1/surveys/:id` | Projektrolle | Entwurf + Revision + letzte Veröffentlichung |
| PATCH | `/api/v1/surveys/:id/draft` | Projekt-Editor + CSRF | aktualisierter Revisionszähler (409 bei Konflikt) |
| POST | `/api/v1/surveys/:id/publish` | Projekt-Editor + CSRF | neuer `slug` / Link |
| GET | `/api/v1/surveys/:id/results` | Projektrolle | aggregierte neueste Antworten |
| GET | `/api/v1/public/s/:slug` | öffentlich | Fragebogensnapshot |
| POST | `/api/v1/public/s/:slug/responses` | öffentlich | idempotente Speicherung einer Abgabe |

**Hinweis:** Eine OpenAPI-Spezifikation, öffentliche Ergebnislinks, CRUD für Benutzerrollen und Exporte fehlen in 0.1.

## Fehlerverhalten

- `400`: fehlerhafte Eingabe oder nicht veröffentlichbare Fragebogendefinition
- `401`: nicht eingeloggt oder Sitzung abgelaufen
- `403`: keine Projektrolle / CSRF-Token falsch
- `404`: Objekt nicht vorhanden oder Publikation geschlossen
- `409`: Entwurfs-Revision veraltet oder wiederholte Abgabe-ID mit anderen Antworten

## Technische Grenzen und Sicherheitsnacharbeiten

1. Die Serverbindung `127.0.0.1` ist **nur für lokale Entwicklung** konfiguriert. Hosting erfordert Proxy, TLS, Umgebungsvariablen, verbindliche Zugriffsregeln und operational security.
2. Veröffentlichungen sind in diesem Stand nach Anlage nicht pausier- oder schließbar über die Oberfläche.
3. Kein Ergebnis-QR-Code und keine externe Freigabe von Reports; Umfragelinks und QR-Codes sind bereits separat.
4. Freitext wird nicht roh im Dashboard angezeigt; die Rohwerte stehen jedoch in der Datenbank und benötigen Datenlebenszyklusregeln.
5. Echte komplexe Verzweigungen und mehrseitige Formulare sind noch nicht implementiert; das Schema enthält eine Seitenstruktur für spätere Erweiterungen.
6. Die Web-App ist ohne zugängliche PostgreSQL-Datenbank nicht voll funktionsfähig; nur der separate Kernlogiktest kann offline laufen.
