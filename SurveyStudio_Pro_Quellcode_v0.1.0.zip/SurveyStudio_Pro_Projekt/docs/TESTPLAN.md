# Testplan / Abnahmefälle – SurveyStudio Pro 0.1

## Automatische Tests (aktuell ausführbar)

`npm test` startet zwei Node-Testgruppen ohne zusätzliche Abhängigkeiten:

1. Kanonischer Entwurf ist gültig, aber ohne Frage nicht veröffentlichbar.
2. Neue Frage, Duplizieren, Verschieben und Entfernen erhalten ein konsistentes Frageschema.
3. Doppelte Frage-IDs und ungültige Antwortoptionen werden zurückgewiesen.
4. Pflichtfeldprüfung, Auswahlrestriktion und manipulierte Frage-Keys werden erkannt.
5. Mehrfachauswahl und explizites `false` bei Ja/Nein werden korrekt geprüft.
6. Auswahlhäufigkeiten werden deterministisch berechnet.
7. Gefährliche SVG-/Skript-Data-URLs werden als Bilder abgelehnt.
8. Bestand der zentralen Projektdateien.
9. SQL-Schema enthält Versionen, Veröffentlichungen, Antworten und Idempotenz-Constraint.
10. Authentifizierungs-Guard prüft CSRF-Header.
11. Optimistischer Entwurfs-Update prüft die Revision im SQL.
12. Pflicht-Textfelder mit nur Leerzeichen werden abgelehnt.
13. Ungültige Kalenderdaten werden erkannt.
14. Numerische Wertebereiche werden geprüft.

## Manuelle Integrationsabnahme (nach Installation ausführen)

| ID | Schritte | Erwartung | Status |
|---|---|---|---|
| IT-01 | `npm install`, Docker starten, Migration ausführen | DB-Tabellen ohne Fehler erstellt | Offen |
| IT-02 | Registrierung mit neuer E-Mail/Passwort ≥12 Zeichen | Arbeitsbereich und erstes Projekt vorhanden | Offen |
| IT-03 | Mit falschem Passwort anmelden | 401, kein Login | Offen |
| IT-04 | Umfrage erstellen, Standardfragetypen einfügen | Alle 9 Typen auswählbar | Offen |
| IT-05 | Frage umbenennen, Optionen bearbeiten, Pflichtfeld setzen | Daten werden gespeichert und wieder geöffnet | Offen |
| IT-06 | Frage per Pfeiltasten/Drag-and-Drop verschieben | Reihenfolge bleibt nach Neuladen erhalten | Offen |
| IT-07 | Akzentfarbe, Schrift, Logo und Hintergrund ändern | Vorschau zeigt Änderungen | Offen |
| IT-08 | Browser schließen/neustarten | Letzter gespeicherter Entwurf wird geladen | Offen |
| IT-09 | Parallel in zwei Browserfenstern denselben Entwurf ändern | Veraltete Speicherung ergibt HTTP 409 | Offen |
| IT-10 | Umfrage ohne Fragen veröffentlichen | Veröffentlichung mit 400 abgewiesen | Offen |
| IT-11 | Umfrage mit Fragen veröffentlichen | Neuer öffentlicher Link und echter QR-Code | Offen |
| IT-12 | Link im privaten Browserfenster öffnen | Fragebogen ohne Login bearbeitbar | Offen |
| IT-13 | Pflichtfrage überspringen, senden | Validierungsfehler angezeigt | Offen |
| IT-14 | gültig ausfüllen, senden | Abschlussmeldung und Speicherung in DB | Offen |
| IT-15 | gleiche `idempotencyKey` erneut senden | kein doppelter Datensatz | Offen |
| IT-16 | gleiche ID mit abweichenden Antworten senden | 409 statt Antwortüberschreibung | Offen |
| IT-17 | Resultatsseite öffnen | Anzahl und Diagrammbalken korrekt | Offen |
| IT-18 | Admin-API ohne Cookie aufrufen | 401 | Offen |
| IT-19 | PATCH ohne X-Survey-CSRF senden | 403 | Offen |
| IT-20 | veröffentlichte Umfrage bearbeiten und neu veröffentlichen | alte und neue Version getrennt, alte Publikation geschlossen | Offen |

**Nicht getestet / nicht enthalten:** Performance, Barrierefreiheit WCAG 2.2 AA, Sicherheits-/Penetrationstest, echte Mandantenisolation, Backup/Restore, Multi-Device Offline-Synchronisierung, Spezielle Fragen (Matrix/Likert etc.), Mail, Datenlöschung, rich-text HTML-Sanitization, Lasttests.
