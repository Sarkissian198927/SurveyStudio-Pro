# Umsetzungsstatus zum Pflichtenheft v1.0

**Bewertung:** Implementierte Quellcodepfade und lokale paketfreie Tests. Ohne installierte Dependencies ist der Integrationsstatus **unverifiziert**. `vollständig` bedeutet hier nur: Code für den bezeichneten Teil vorhanden; noch keine Produktfreigabe.

| Anforderung | Entwicklungsstand in diesem Paket | Einschränkung |
|---|---|---|
| F-001 Registrierung/Login | Teilimplementierung | E-Mail-Verifikation/Reset nicht vorhanden |
| F-002 Organisation/Projekte | Teilimplementierung | Registrierung erzeugt Organisation/Projekt, noch keine Einladungs-UI |
| F-003 Umfragen/Entwurf | Teilimplementierung | Erstellen, Laden, Speichern; duplizieren/archivieren fehlen |
| F-004 Drei-Spalten-Designer | Implementiert im Frontend-Code | Drag-and-Drop und Pfeiltasten im manuellen Test noch prüfen |
| F-005 neun Kernfragetypen | Implementiert in Schema/Renderer | E2E noch ausstehend |
| F-006 Gestaltungsgrundlagen | Teilimplementierung | Farben/Fonts/Logo/BG, kein Rich-Text-HTML-Editor |
| F-007 Begrüßung/Abschluss | Teilimplementierung | Textfelder und separate Ansichten, nur eine Fragebogenseite |
| F-008 Versionen | Implementiert im API-/DB-Code | Keine Versionsvergleichs-UI |
| F-009 Öffentliche Publikation/QR | Teilimplementierung | Link/QR vorhanden, zeitliche Begrenzung/Pausierung noch ohne UI |
| F-010 Antwortsystem | Implementiert im Code | Integration mit PostgreSQL noch nicht ausgeführt |
| F-011 Basisauswertung | Teilimplementierung | Tabellen/Balken, keine Zeitreihe/Kreuztabelle |
| F-012 Exporte | Nicht implementiert | CSV/XLSX/PDF noch offen |
| F-013 Privacy-Modi | Nur anonymer Modus vorgesehen | DSGVO-Abnahme und Privacy-Risikoanalyse offen |
| F-014 Rechte | Projektrollen im API-Code | Feingranulare Permissions/Ergebnisrollen fehlen |
| F-015 Ergebnisse teilen | Nicht implementiert | Nur private Admin-Ergebnissicht |
| F-016 Assets | Provisorisch | Data-URLs in Entwürfen, kein Objekt-Storage |
| F-017 Autosave | Implementiert im Frontend-Code | Race-/Browserintegration noch prüfen |
| F-018–F-040 | Nicht implementiert | Geplante spätere Entwicklungsphasen |

## Release-Gate vor öffentlicher Nutzung

Für die öffentliche Nutzung mit personenbezogenen Daten sind mindestens folgende Punkte vorab nachzuholen: verifizierte Authentifizierung und Account-Lifecycle, Rate-Limiting, Missbrauchsschutz, sichere Hosting-/TLS-Konfiguration, Secret-Rotation, DSGVO-/TOM-Prüfung, Anonymisierungsrisiko, Lösch-/Auskunftsprozesse, Backups mit Restore-Test, Audit-Härtung, Ergebnis-Mindestfallzahlregeln, Last- und Barrierefreiheitstests sowie vollständige E2E-Abnahme.
